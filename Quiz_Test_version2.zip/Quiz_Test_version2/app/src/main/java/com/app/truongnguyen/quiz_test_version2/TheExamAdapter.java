package com.app.truongnguyen.quiz_test_version2;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.util.ArrayList;

public class TheExamAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private ArrayList<Object> mArrayList;
    private boolean[] theUsersAnswer;
    private Context mContext;

    private static final int SINGLECHOICE = 1;
    TheExamAdapter(ArrayList<Object> mArrayList, Context context) {
        this.mArrayList = mArrayList;
        this.mContext = context;
        theUsersAnswer = new boolean[getItemCount()];
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int typeItem) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        String TAG = "TheExamAdapter";
        if (typeItem == SINGLECHOICE) {
            return new SingleChoiceQuizHolder(layoutInflater.inflate(
                    R.layout.row_single_choice, viewGroup, false));
        }
        return null;
    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int pos) {

        Object object = mArrayList.get(pos);
        String numberOrder = "Câu " + (pos + 1) + ": ";

        if (getItemViewType(pos) == SINGLECHOICE) {// để cho cái file theme -__-
            // thế này khó đọc vch theme là sao?
            SingleChoiceQuizHolder s = (SingleChoiceQuizHolder) viewHolder;
            SingleChoiceQuiz singleChoiceQuiz = (SingleChoiceQuiz) object;
            s.mTextViewQuestion.setText(numberOrder + singleChoiceQuiz.mQuestion);
            s.createAndInsertRadioButtons(singleChoiceQuiz.mStringAnswer);
        }
    }

    @Override
    public int getItemViewType(int position) {
        Object object = mArrayList.get(position);
        if (object instanceof SingleChoiceQuiz)
            return SINGLECHOICE;
        return super.getItemViewType(position);
    }

    @Override
    public int getItemCount() {
        return mArrayList.size();
    }

    public class SingleChoiceQuizHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView mTextViewQuestion;
        private RadioGroup mRadioGroup;

        SingleChoiceQuizHolder(@NonNull View itemView) {
            super(itemView);
            mTextViewQuestion = itemView.findViewById(R.id.tv_single_choice_question);
            mRadioGroup = itemView.findViewById(R.id.rg_single_choice_answer);
        }

        void createAndInsertRadioButtons(String[] arrayAnswer) {
            if (mRadioGroup.getChildAt(0) != null)
                return;
            for (int i = 0; i < arrayAnswer.length; i++)
                mRadioGroup.addView(createRadioButtonAnswerAndSetOnClickListener(
                        Character.toString((char) (65 + i)) + ". " + arrayAnswer[i]));
        }

        RadioButton createRadioButtonAnswerAndSetOnClickListener(String s) {
            RadioButton radioButton = new RadioButton(mContext);
            radioButton.setText(s);
            radioButton.setTextSize(22);
            radioButton.setOnClickListener(this);
            return radioButton;
        }

        @Override
        public void onClick(View v) {
            int pos = getAdapterPosition();
            Object object = mArrayList.get(pos);
            int posOfCorrectAnswer = ((SingleChoiceQuiz) object).mPositionCorrectAnswer;
            RadioButton r = (RadioButton) mRadioGroup.getChildAt(posOfCorrectAnswer);
            theUsersAnswer[pos] = r.isChecked();
        }
    }
}

