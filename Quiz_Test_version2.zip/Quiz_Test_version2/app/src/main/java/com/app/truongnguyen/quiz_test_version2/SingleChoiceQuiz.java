package com.app.truongnguyen.quiz_test_version2;

class SingleChoiceQuiz {
    String mQuestion;
    String[] mStringAnswer;
    int mPositionCorrectAnswer;

    SingleChoiceQuiz(String mQuestion, String[] mStringAnswer, int mPositionCorrectAnswer) {
        this.mQuestion = mQuestion;
        this.mStringAnswer = mStringAnswer;
        this.mPositionCorrectAnswer = mPositionCorrectAnswer;
    }
}
