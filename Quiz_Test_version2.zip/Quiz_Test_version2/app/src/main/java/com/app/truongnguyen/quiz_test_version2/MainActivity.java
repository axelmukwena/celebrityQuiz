package com.app.truongnguyen.quiz_test_version2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Object> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView recyclerView = findViewById(R.id.recyclerView_theExam);
        for (int i = 0; i < 10; i++)
            loadData();
        arrayList.add("Gửi");
        TheExamAdapter theExamAdapter = new TheExamAdapter(arrayList, this);
        recyclerView.setAdapter(theExamAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void loadData() {
        arrayList.add(new SingleChoiceQuiz("Châu Âu gồm những nước nào?",
                new String[]{"Mỹ", "Pháp", "Anh", "Trung Quốc"}, 2));
        arrayList.add(new SingleChoiceQuiz("|x|=1 thi x=?",
                new String[]{"x=1", "x=-1", "x=0"},  1));
        arrayList.add(new SingleChoiceQuiz("2 * 3 = ?",
                new String[]{"48", "6", "28777"}, 1));
        arrayList.add(new SingleChoiceQuiz("10 - 2 + |3|=?",
                new String[]{"172", "126", "32", "213", "43"}, 1));
    }
}
